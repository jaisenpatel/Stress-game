using UnityEngine;
using System.Collections;


// Make these publicly accessible.
public enum gameStates { Idling, PlayerX, PlayerO, VictoryAnimation};


public class GameController : MonoBehaviour {
	
	// Game Controller states are: 
	// "Idling" = idle state, waiting for player to click "Play".
	// "PlayerX" = X's turn. 
	// "PlayerO" = O's turn.
	// "VictoryAnimation" = a victory condition has been reached. This is where a "Player [X or O] WINS!" sequence would be run, after which the state changes to "Idling".
	
	private gameStates _gameState;
	
	public gameStates gameState
	{
		get 
		{
			return _gameState; 
		}
		set 
		{	
			if (value != _gameState)	// This ensures we only call GameStateHasChanged() if it's actually changed.
			{
				_gameState = value;
				GameStateHasChanged();	// call any code relying on gameState changes. Note, this is NOT a C# "Event", so I'm not using the "On..." naming convention.
			}
		}
	}
		
	public GameUI gameUI;		// points to our View code ("GameUI").
	public GameBoard board;		// points to our Model code ("GameBoard").
	public AIPlayers aiPlayer;	// points to AIPlayers script.
	
	// Use this for initialization
	void Start () {
	
		gameState = gameStates.Idling;		// the player has to click on "Play" in the menu.
		
		aiPlayer = GameObject.Find ("AIPlayers").GetComponent<AIPlayers>();
		board = GameObject.Find ("GameModel").GetComponent<GameBoard>();
		gameUI = Camera.main.GetComponent<GameUI>();	// our UI script is in the main camera GameObject.
		
		if (board==null)
		{
			Debug.LogError ("Board not found!");
		}

		if (gameUI==null)
		{
			Debug.LogError ("GameUI not found!");
		}

		if (aiPlayer==null)
		{
			Debug.LogError ("AIPlayers not found!");
		}
	}
	
	// Called by UI to set the AI player.
	public void SetAIPlayer(int player)
	{
		switch (player)
		{
		case 0:
			aiPlayer.AIPlayerName = AIPlayerNames.Tom;
			break;
		case 1:
			aiPlayer.AIPlayerName = AIPlayerNames.Dick;
			break;
		case 2:
			aiPlayer.AIPlayerName = AIPlayerNames.Harry;
			break;
		default:
			aiPlayer.AIPlayerName = AIPlayerNames.none;
			break;	
		}
	}
	
	public void AIPlaysX(bool x)
	{
		aiPlayer.isX = x;	// tell the AI code whether it will be playing as 'X' or 'O'.
	}
	
	// LateUpdate is called at the end of each physics engine cycle.
	void LateUpdate () {
		
		if (board.boardState == GameBoard.boardStates.init)
		{
			SmoothFollow script = Camera.main.GetComponent<SmoothFollow>();
			script.distance = 40 + ( (board.boardSize-3) * 10.0f);
			board.boardState = GameBoard.boardStates.playing;	// board is ready for play.
		}
			
	}
		
	// This function is called by changes to the gameState variable whenever the player has made a move on the board. (See the definition for how this is done.)
	// Our Controller can thus tell GameBoard to make its check for a victory condition. (In the initial release, GameBoard performed that check in its own Update() cycle.)
	public void GameStateHasChanged ()
	{
		
		board.CheckForVictoryCondition();	// This sets the GameBoard state accordingly.

		// Now check if the Model has detected a victory condition: 
		if (board.boardState == GameBoard.boardStates.stalemate)
			gameUI.GameOverSequence(GameUI.Sequences.Stalemate);	// tell our View to run the relevant game over sequence.
		else
			if (board.boardState == GameBoard.boardStates.winnerIsX)
				gameUI.GameOverSequence(GameUI.Sequences.XWins);	// ditto.
			else
				if (board.boardState == GameBoard.boardStates.winnerIsO)
					gameUI.GameOverSequence(GameUI.Sequences.OWins);	// again, ditto.
		
				else {
					
				// Handle the AI Player.
		
					if ( ((gameState == gameStates.PlayerX) && (aiPlayer.isX == true)) ||  ((gameState == gameStates.PlayerO) && (aiPlayer.isX == false)) )
					{
						gameUI.isGUIEnabled = false; 	// disable the GUI and prevent the player clicking any other cells until we're done making our move.
						aiPlayer.PlayAITurn();			// play turn.
						// note that we don't re-enable the GUI here. That's done in the GameUI script itself, inside a coroutine.
					}
				}
	}
		
	
	// Play AI move at indicated board position, with indicated shape and AI player.
	// As we want the animation sequence (such as it is) to complete before the move is played, the PlayMoveAt functions in GameUI will call the Controller's "PlayMoveNow()" function when
	// the animation has completed, so we don't actually play the move here.
	
	public void PlayMoveAt(int ix, int iy, bool isX, AIPlayerNames name)
	{
		// Uncomment the following line to see the AI player's move coordinates in the debug console.
		// Debug.Log ("Playing Move at ("+ix+", "+iy+")");
		
		gameUI.AnimateMove(ix, iy, isX, name);	// this is why MVC isn't always ideal: we're having to throw this out to the UI code because that's where the animations are done.
	
	}

	// This function is called by the GameUI script when the "[AI name] is thinking" animation has completed.
	// This is where the AI player's move is actually performed.
	public void PlayMoveNow(int ix, int iy, bool isX)
	{
		board.PlayMoveAt(ix, iy, isX);	// finally, we can play the move!
		
		// Update the Game State. This also triggers a scan of the board for victory conditions, so it needs to be here, immediately after the move is played.
		// If we put this in the "PlayMoveAt()" function, the Co-routine that handles the animation sequence won't have finished, so the state would change before the move has been played. 
		if (gameState == gameStates.PlayerX)
			gameState = gameStates.PlayerO;
		else
			gameState = gameStates.PlayerX;	
	}

	public void ResetBoard()
	{
		board.ResetBoard();
		gameState = gameStates.Idling;
	}
		
}
