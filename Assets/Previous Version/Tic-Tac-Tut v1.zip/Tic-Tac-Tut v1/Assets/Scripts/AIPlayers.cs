using UnityEngine;
using System.Collections;

//	This script contains the AI player code. 
//	This code doesn't fit into the "MVP" pattern as it is neither Model, View nor Presenter. It's a computer simulated player.
//	There's an awful lot of Dick in this script. Sorry about that.


public enum AIPlayerNames {none, Tom, Dick, Harry};							// Make this publically visible. It makes for much less typing!

// The following defines a lightweight struct representing two ints. This saves faffing about converting the alternative "Vector2" floats to ints later on.
public struct Coords 
{
	public int x, y;
}

public class AIPlayers : MonoBehaviour {

	private GameController controller;
	private GameBoard board;
	
	private enum diagonals {none, backslash, slash, both}	// used when checking diagonal rows. "Backslash" and "slash" correspond to the '\' and '/' diagonals respectively. 
	public AIPlayerNames AIPlayerName;
	
	public int dickIntelligence = 1;	// Every time Harry plays, we pick a random number between 0 and 5. If the number is greater than this value, Harry plays an intelligent move.
										// Otherwise, Harry just picks a random empty square.
	
	private bool _isX;		// set to True if AI Player is playing as "X", else assume it is playing as "O"

	public bool isX
	{
		get
		{
			return _isX;
		}
		set
		{
			_isX = value;
		}
	}	
	
	// Use this for initialization
	void Start () {
		
		controller = GameObject.Find("GameController").GetComponent<GameController>();
		board = GameObject.Find ("GameModel").GetComponent<GameBoard>();

		if (!controller)
		{
			Debug.Log("ERROR: Controller not found.");
		}
		
		if (!board)
		{
			Debug.Log("ERROR: Board not found.");
		}
		
		if ( AIPlayerName == AIPlayerNames.none )
			AIPlayerName = AIPlayerNames.Tom;	// set default AI player.
				
	}

	// This function is called whenever it's the AI Player's turn.
	// You'll note that the AI Player
	public void PlayAITurn()
	{
		
		// We have a different algorithm for each player 'character'...
		switch (AIPlayerName)
		{
				// The "Tom" character simply picks a square at random. 
			case AIPlayerNames.Tom:
				PlayRandomEmptyCell(AIPlayerNames.Tom);						// Just play a random empty square.
				break;

				// "Dick" is a compromise "nearly perfect" player; 
			case AIPlayerNames.Dick:
				if (Random.Range(0, 5) > dickIntelligence)		// Roll our six-sided die. Did we roll a number greater than our intelligence setting?
					PlayIntelligentMove(AIPlayerNames.Dick);			// If so, play an intelligent move...
				else
					PlayRandomEmptyCell(AIPlayerNames.Dick);			// ... if not, play a random empty square.
				break;
			
			case AIPlayerNames.Harry:							// The "Harry" character plays uses only the "perfect" AI algorithm.
				PlayIntelligentMove(AIPlayerNames.Harry);		// In theory, the only way you should be able to beat "Harry" is if you pick the centre square before he does.
				break;											// And even then, you're more likely to end up with a draw.
			
			default:
				break;
		}
				
				
	}
	
			
	// Find a good move and play it. Used by both "Dick" and "Harry" AI characters. 
	// "Harry" always uses this function, while "Dick" alternates this with PlayRandomEmptyCell() at a frequency defined by "AIDickStupidity".  
	// NOTE: This code is optimized for a traditional 3x3 Tic-Tac-Toe grid. If you want to use larger grid sizes, you'll need to change it.

	void PlayIntelligentMove(AIPlayerNames name)
	{
		cellStates[,] theBoard = new cellStates [board.boardSize, board.boardSize];
		
		board.GetBoard(ref theBoard);	// populate our array with the current cell states.		
		
		int [,] scoreBoard = new int [board.boardSize, board.boardSize];	// create our scoreboard array.

		// initialise the scoring array...
		for (int ix = 0; ix < board.boardSize; ++ix)
			for (int iy = 0; iy < board.boardSize; ++iy)
				scoreBoard[ix, iy] = -1;

		// We now go over the board and give a score for each remaining empty cell...
		for (int ix = 0; ix < 3; ++ix)
		{	
			for (int iy = 0; iy < board.boardSize; ++ iy)
			{
				if (theBoard[ix, iy] == cellStates.isEmpty)
					// Find a score for this cell...
					SetCellScore(ix, iy, ref scoreBoard, ref theBoard);
			}
		}
		
		// Uncomment the following code to see what the scoring array (in "scoreBoard") contains. 
		// The data is printed to the console, so you'll need to bring that up from Unity's Windows menu.
/*
		Debug.Log ("Scoring array:");
		for (int ix = 0; ix < board.boardSize; ++ix)
			for (int iy = 0; iy < board.boardSize; ++iy)
			{
				Debug.Log ("("+ix+", "+iy+") = " + scoreBoard[ix, iy].ToString() + "; state = " + theBoard[ix, iy].ToString() );
			}
*/
		
		// Now that we've got our scoreboard initialised, let's go find the highest score on it.
		
		int highX=0, highY=0, highScore=-1;
		
		for (int ix = 0; ix < board.boardSize; ++ix)
		{
			for (int iy = 0; iy < board.boardSize; ++iy)
			{
				if (scoreBoard[ix, iy] != -1 && scoreBoard[ix,iy] > highScore)
				{	
					highX=ix; highY=iy; 
					highScore=scoreBoard[ix, iy];	// Store value and coordinates of highest score found so far.
				}
			}
		}
	
		// play the move...

		if (highScore != -1)		// did we find a good score?
			controller.PlayMoveAt(highX, highY, isX, name);	// play the location of the high score.
		else
			PlayRandomEmptyCell(name);			// just play a random square if not.
		
	}
	
	// This function checks if we're on a diagonal and, if so, which one. This determines the check(s) we need to perform.
	// Note the board size has 1 subtracted from it because arrays are indexed from zero, not one. This is a common source of bugs!
	diagonals CheckForDiagonals(int x, int y)
	{
		diagonals diag = diagonals.none;
		if (x == 0 && y == 0)
			diag = diagonals.slash;
		if (x == board.boardSize-1 && y == 0)
			diag = diagonals.backslash;
		if (x == 0 && y == board.boardSize-1)
			diag = diagonals.backslash;
		if (x == board.boardSize-1 && y == board.boardSize-1)
			diag = diagonals.slash;
		
		if (x == board.boardSize / 2 && y == board.boardSize / 2)
			diag = diagonals.both;	// this is the centre square.
		
		return diag;
	}
	
	
	int CheckScores (int currentScore, int theirScore, int myScore)
	{
		
		if (theirScore > board.boardSize / 2)	// have we found more than one "theirCell" in the row?
			theirScore = 10;	// return a very high score as we need to block it.
		if (myScore > board.boardSize / 2)	// Can we win the game by playing this cell?
			myScore = 20;		// If so, return an even higher score as it doesn't matter if the opponent player can win in their next move: they won't get the chance!
		
		if ( (currentScore > theirScore) && (currentScore > myScore) )	// no change in score
			return currentScore;
		
		// one of the scores is the new high score, so return that:
		return (theirScore > myScore) ? theirScore : myScore;	// return the largest of the two scores.
	}
	
	// Determine scoring for specified cell on board.
	void SetCellScore (int x, int y, ref int[,] b, ref cellStates[,] bStates)
	{

		int score, theirScore, myScore;	
		cellStates theirCell, myCell;

		theirCell = isX ? cellStates.isX : cellStates.isO;	// If you don't know what this does, look up the "ternary operator" for C#. It's a contraction of the "if...else" construct.
		myCell = isX ? cellStates.isO : cellStates.isX;	
						
		// The following assumes a 3 x 3 board size. It will not work for larger boards!
		
		// The Heuristic:
		// Check for each possible sequence: horizontal, vertical and diagonal (but only check the latter when necessary).
		// If there are two "theirCell" states, we need to block the row with our own piece.
		// If there are two "myCell" states in a row, we should complete the sequence and thus win the game!
		
		score = 0; theirScore = 0; myScore = 0;
		
		// Are we at the centre cell? This is tactically a very useful position: we're more likely to win if we take it.
		
		if (x == board.boardSize/2 && y == board.boardSize/2)
			score = 5;

		// horizontal row first...
		
		for (int ix = 0; ix < board.boardSize; ++ix)
		{
			if ( bStates[ix, y] == theirCell)
			{
				++theirScore;
			}
			else if ( bStates [ix, y] == myCell)	// if this is true, the row is already blocked.
			{
				++myScore;
			}
		}
		
		score = CheckScores (score, theirScore, myScore);
		
		// vertical row...
		
		theirScore = 0; myScore = 0;
		for (int iy = 0; iy < board.boardSize; ++iy)
		{
			if ( bStates[x, iy] == theirCell)
			{
				++theirScore;
			}
			else if ( bStates [x, iy] == myCell)	// if this is true, the row is already blocked.
			{
				++myScore;
			}
		}
		
		score = CheckScores(score, theirScore, myScore);
		
		// Finally, check the diagonals, but ONLY if we are looking at one of the cells on the diagonals!
		
		
		diagonals test = CheckForDiagonals(x,y);
		
		switch (test)
		{
		case diagonals.slash:
			theirScore = 0; myScore = 0;
			for (int ix = 0; ix < board.boardSize; ++ix)
			{
				if (bStates[ix, ix] == theirCell)
					++theirScore;
				if (bStates[ix, ix] == myCell)
					++myScore;
			}		
			
			score = CheckScores(score, theirScore, myScore);
			break;
			
		case diagonals.backslash:
			theirScore = 0; myScore = 0;
			for (int ix = 0; ix < board.boardSize; ++ix)
			{
				if (bStates[(board.boardSize-1)-ix, ix] == theirCell)
					++theirScore;
				if (bStates[(board.boardSize-1)-ix, ix] == myCell)
					++myScore;
			}
			score = CheckScores(score, theirScore, myScore);
			break;
			
		case diagonals.both:	// This only gets used if we're looking at an empty centre cell. 
								// As the "perfect" AI code already checks to see if the centre cell has been taken, it's extremely rare to see this code called.
								// However, 'Dick', the "nearly perfect" AI player, can make one or more random moves before calling this AI function, so we need to allow for it.  

			// slash ("/") diagonal

			theirScore = 0; myScore = 0;
			for (int ix = 0; ix < board.boardSize; ++ix)
			{
				if (bStates[ix, ix] == theirCell)
					++theirScore;
				if (bStates[ix, ix] == myCell)
					++myScore;
			}
			score = CheckScores(score, theirScore, myScore);

			// now check the other diagonal...
			
			theirScore = 0; myScore = 0;
			for (int ix = 0; ix < board.boardSize; ++ix)
			{
				if (bStates[(board.boardSize-1)-ix, ix] == theirCell)
					++theirScore;
				if (bStates[(board.boardSize-1)-ix, ix] == myCell)
					++myScore;
			}
			score = CheckScores(score, theirScore, myScore);

			break;
			
		default:
			break;
		}
		
		// Finally, store the score in the board. This is passed by reference, so we're actually changing the array held by the calling function.
		b[x,y] = score;
	}

	
	void PlayRandomEmptyCell(AIPlayerNames name)
	{
		cellStates[,] cs = new cellStates [board.boardSize, board.boardSize];
		
		board.GetBoard( ref cs);	// fill our array with the current board state. We're passing our array here by reference, so GetBoard will fill it directly.
		
		// now iterate through the array and count all the empties...
		
		int empties=0;

		
		Coords[] emptyCells = new Coords[board.boardSize*board.boardSize];	// allow for a completely empty board's worth of coordinates.
		
		for (int ix = 0; ix < board.boardSize; ++ix)
		{	
			for (int iy = 0; iy < board.boardSize; ++ iy)
			{
				if (cs[ix,iy] == cellStates.isEmpty)
				{
					// found an empty space. Add it to our array...
					emptyCells[empties].x = ix;
					emptyCells[empties].y = iy;
					++empties;
				}		
			}
		}

		// now generate a random number in the range 0 - "empties"...
		int pick = Random.Range (0, empties);
		
		// now play the cell at that location:
		controller.PlayMoveAt(emptyCells[pick].x, emptyCells[pick].y, isX, name);
	}

}
