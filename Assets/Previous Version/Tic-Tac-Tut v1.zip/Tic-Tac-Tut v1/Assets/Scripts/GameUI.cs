using UnityEngine;
using System.Collections;

public class GameUI : MonoBehaviour {

	// This class handles the "View" part of our Model-View-Controller setup...
		
	public Texture2D stalemateTex;
	public Texture2D winnerIsXTex;
	public Texture2D winnerIsOTex;
	public Texture2D titleTex;
	
	// Our AI players...
	public Texture2D tomThinkingTex;
	public Texture2D dickThinkingTex;
	public Texture2D harryThinkingTex;
	
	private Texture2D activeTexture;
		
	public GameController controller;	// link to the Controller GameObject. The View shouldn't know about the Model; all communication goes via the Controller.
		
	public enum Sequences { Stalemate, XWins, OWins, TomThinking, DickThinking, HarryThinking }	// animation sequences.
			
	private Vector2 displaySize;
	
	private float playAsX_BtnX, playAsX_BtnY, playAsO_BtnX, playAsO_BtnY, textLabel_X, textLabel_Y, resetBtnX, resetBtnY, titleText_X, titleText_Y, AIButtons_X, AIButtons_Y;

	// The next two are used for the AI selection radio buttons. (Unity Technologies have named these "Toolbars" for some reason.)
	private int radioButtonSelection = 0;	// Unity's "GUI.Toolbar" element is known everywhere else as a "radio button": only one button can be pressed at any time.
	private string[] radioButtonNames = {"Tom", "Dick", "Harry"};

	[HideInInspector]
	public bool isGUIEnabled;	// set to false during game over sequences.	
	

	void Awake () {
	
		isGUIEnabled = true;		// enable GUI.
						
		// now work out the screen coordinates for the GUI elements...
		
		titleText_X = 10.0f; 
			titleText_Y = 10.0f;	// set position of game title (the large square "Tic-Tac-Tut" image.)
		
		textLabel_X = 20.0f; 
			textLabel_Y = titleText_Y + 256.0f;
	
		AIButtons_X = 20.0f;
		AIButtons_Y = titleText_Y + 290.0f;

		playAsX_BtnX = 20.0f;
			playAsX_BtnY = AIButtons_Y + 40.0f;
						
		playAsO_BtnY = playAsX_BtnY + 60.0f;
	
		resetBtnX = playAsO_BtnX = playAsX_BtnX;	// two for the price of one!

		resetBtnY = playAsX_BtnY+ 20.0f;	
		
		activeTexture = titleTex;
				
	}
	
	// Update is called once per frame
	void Update () {
		
		if (isGUIEnabled)
		{
			
			if (Input.GetButtonDown ("Fire1")) 
			{
	        	// Construct a ray from the current mouse coordinates
	        	Ray ray = Camera.main.ScreenPointToRay (Input.mousePosition);
				RaycastHit hit;
	        	if (Physics.Raycast (ray, out hit))
					if (controller.gameState==gameStates.PlayerO || controller.gameState==gameStates.PlayerX)	// ensure player is allowed to play!
					{
						// player has clicked on something. Check if the raycast intersects with the board...
						BoardCellState cellScript = hit.collider.GetComponent<BoardCellState>();
						if (cellScript)	// player has clicked on one of the game board's cells...
						{
							// if you are a university Computer Science professor, look away now! 
							// The following isn't quite in the spirit of MVC, but it does the job with a lot less code. Less code = fewer bugs. So there.
							if (cellScript.cellState==cellStates.isEmpty)	// make sure the move is legal!
							{
								// We really need to know which player is playing, so find out...
								if (controller.gameState == gameStates.PlayerO)
								{
									cellScript.cellState = cellStates.isO;
									// need to tell Controller to switch players. Ordinarily, you'd do something fancy here, but it's late and I want to go to bed:
									controller.gameState = gameStates.PlayerX;
								}
								else
								{
									cellScript.cellState = cellStates.isX;
									// need to tell Controller to switch players. As above, I'm just going to change the Controller's state...
									controller.gameState = gameStates.PlayerO;	// you'd probably want to give the players a visual cue in a real game.
								}
							}
						}
					}
				}
			}
	}
	
	void SetTexture(Sequences seq)
	{
		switch (seq)
		{
			case Sequences.Stalemate:
				activeTexture = stalemateTex;
				break;
			case Sequences.XWins:
				activeTexture = winnerIsXTex;
				break;
			case Sequences.OWins:
				activeTexture = winnerIsOTex;
				break;
			case Sequences.TomThinking:
				activeTexture = tomThinkingTex;
				break;
			case Sequences.DickThinking:
				activeTexture = dickThinkingTex;
				break;			
			case Sequences.HarryThinking:
				activeTexture = harryThinkingTex;
				break;			
			
		}
		
	}

	public void AnimateMove(int x, int y, bool isX, AIPlayerNames name)
	{
		StartCoroutine(PlayMove (x, y, isX, name));
	}
	
	IEnumerator PlayMove(int x, int y, bool isX, AIPlayerNames name)
	{
		switch (name)
		{
		case AIPlayerNames.Tom:
			SetTexture (Sequences.TomThinking);
			break;
		case AIPlayerNames.Dick:
			SetTexture (Sequences.DickThinking);
			break;
		case AIPlayerNames.Harry:
			SetTexture (Sequences.HarryThinking);
			break;
		default:
			break;				
		}
				
		// Wait for a couple of seconds to give the players time to read the graphic, letting it sink in and enrich their otherwise empty lives... 
		
		yield return new WaitForSeconds(1);	

		isGUIEnabled = true;		// re-enable UI interactions. The UnityGUI elements will reappear at this point.
		
		activeTexture = titleTex;	// restore our "Tic-Tac-Tut" texture.
		
		controller.PlayMoveNow(x, y, isX);
		
	}
	
/* This is a "Coroutine". Coroutines run in parallel with the main thread, so they are a form of multithreading your code. 
	
	Note that the "Yield" instruction only works inside a Coroutine.

	Coroutines written in C# or Boo require the "IEnumerator" return type. Javascript does not require this.
	
 */
	
	IEnumerator DoSequence(Sequences seq, bool isGameOver = false)
	{
		isGUIEnabled = false;	// disable all UI interactions while sequence is run. 
		
		SetTexture(seq);
		
		// Wait for a couple of seconds to give the players time to read the graphic, letting it sink in and enrich their otherwise empty lives... 
		
		yield return new WaitForSeconds(2);	
		
		isGUIEnabled = true;		// re-enable UI interactions. The UnityGUI elements will reappear at this point.
		
		activeTexture = titleTex;	// restore our "Tic-Tac-Tut" texture.

		// now check if the sequence was a "GameOver" sequence. If it was, we need to tell the Controller to tell the Board to clear itself. (Confusing, isn't it?)
		
		if (isGameOver)
			controller.ResetBoard();
	}

	// Game Over sequences. Exactly like PlaySequence(), below, but we want the board to be cleared at the end too.	
	public void GameOverSequence(Sequences sequence)
	{
		StartCoroutine (DoSequence (sequence, true));	// ... start sequence. Note the Boolean parameter: this is a Game Over sequence, so we want the board to be reset!
		
		// DoSequence() is a Coroutine and therefore "returns" control immediately to this function; we don't wait until the Coroutine has finished.
		// This makes the decision of when and where to put calls to other functions very important.
		// 
		// For example: you'll note that the call to the Controller's "GameOver()" function is done inside the Coroutine, not here. 
		//				If we called it here, the board would be reset before the sequence has had a chance to complete.

	}
		
	// Play an animation sequence. We don't want the board to be reset at the end as these are in-game sequences and not Game Over sequences.
	public void PlaySequence(Sequences sequence)
	{
		StartCoroutine (DoSequence (sequence, false));
	}
	
		


	void OnGUI () {

		GUI.Label (new Rect (titleText_X, titleText_Y, 512.0f, 256.0f), activeTexture);	// draws the "TIC-TAC-TUT" graphic.
		
		// Only show GUI if it's available. If a victory animation is playing, we hide it.
		if (isGUIEnabled)
		{
			// Set the text label:
			switch (controller.gameState)
			{
				case gameStates.Idling:
					GUI.Label (new Rect(textLabel_X, textLabel_Y, 250.0f, 50.0f), "Choose opponent and start a new game.");
					break;
				
				case gameStates.PlayerO:
					GUI.Label (new Rect(textLabel_X, textLabel_Y, 150.0f, 50.0f), "Playing as: O");
					break;
				case gameStates.PlayerX:
					GUI.Label (new Rect(textLabel_X, textLabel_Y, 150.0f, 50.0f), "Playing as: X");
					break;		
			}
			
			// Display the rest of the GUI.
			if (! (controller.gameState == gameStates.PlayerO || controller.gameState == gameStates.PlayerX) )
			{
				if ( GUI.Button (new Rect (playAsX_BtnX, playAsX_BtnY, 150.0f, 50.0f), "Play as 'X'") )
				{
					controller.AIPlaysX(false);	// AI Player plays "O"	

					controller.gameState = gameStates.PlayerX;
				}
				
				if ( GUI.Button (new Rect (playAsO_BtnX, playAsO_BtnY, 150.0f, 50.0f), "Play as 'O'") )
				{
					controller.AIPlaysX(true);	// AI Player plays "X"	

					controller.gameState = gameStates.PlayerO;
				}

				// Offer a choice of AI players.		
				radioButtonSelection = GUI.Toolbar (new Rect (AIButtons_X, AIButtons_Y, 250.0f, 30.0f), radioButtonSelection, radioButtonNames);

			}
			else
			{
				if (GUI.Button (new Rect (resetBtnX, resetBtnY, 150.0f, 50.0f), "RESIGN GAME"))
				{
					controller.ResetBoard();
				}
			}

		}
		
		if (GUI.changed)
			controller.SetAIPlayer(radioButtonSelection);
			
	}
	
}
