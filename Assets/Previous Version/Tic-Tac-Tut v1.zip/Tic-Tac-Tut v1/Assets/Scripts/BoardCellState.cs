using UnityEngine;
using System.Collections;

// This class contains the state for the board cell. 
// In this case, it contains a simple CellState FSM variable that determines if the cell should be displayed with an 'X' or 'O', or as an empty cell.

public enum cellStates {isEmpty, isX, isO};	// visible across all modules.

public class BoardCellState : MonoBehaviour {
	
	public Material materialEmpty;
	public Material materialX;
	public Material materialO;

	private bool stateHasChanged = false;

	private cellStates _cellState;	
	public cellStates cellState
	{
		get
		{
			return _cellState;
		}
		set
		{
			if ( _cellState != value)
			{
				_cellState = value;
				stateHasChanged = true;
			}
		}
	}
	
	
	// Use this for initialization
	void Start () {
			
	}
	
	// Update is called once per frame
	void Update () {

		if (stateHasChanged)
		{
			switch (cellState)
			{
				case cellStates.isEmpty:
				{
					// set material to empty material here.
					transform.renderer.material = materialEmpty;
					break;	
				}
				case cellStates.isX:
				{
					// set material to 'X' here.
					transform.renderer.material = materialX;
					break;
				}
				case cellStates.isO:
				{
					// set material to 'O' here.
					transform.renderer.material = materialO;
					break;
				}
					
			}
			stateHasChanged = false;
		}
	}
}
