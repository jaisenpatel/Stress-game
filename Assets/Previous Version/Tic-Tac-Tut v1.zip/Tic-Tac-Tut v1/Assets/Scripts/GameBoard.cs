using UnityEngine;
using System.Collections;

// This script acts as our "Model". It doesn't handle "View" or "Controller" elements. Those are external scripts which link to this.

// As a rule, the MVC design pattern allows the Controller to talk to the View and the Model. 
// Neither the View nor the Model should ever talk to each other directly: they must always do so via the Controller.

public class GameBoard: MonoBehaviour {
	
	public GameController gc;	// pointer to the game controller script. (This is the "C" part of the "MVC" design pattern.)
	
	public enum boardStates { init, playing, winnerIsX, winnerIsO, stalemate}	// defines the states for our board's basic FSM.
	
	public boardStates boardState;		// Updates to show board state. The game is over if set to either "winnerIsX" or "winnerIsO".
	
	public GameObject cellPrefab;	// pointer to board square prefab. This script will use it to build the game board.

	public int boardSize = 3;	// the size of the board -- in this case, it's a traditional 3 x 3 board.
	
	public float cellPrefabWidth =0.0f, cellPrefabHeight=0.0f;	// initialised in Start() function.
		
	private float minWidth = 10.5f, minHeight = 10.5f;		// default spacing betwen each board's cell. If the cellPrefabWidth/Height variables are 0, these values are used instead.

	private GameObject[,] theBoard;				// used to contain all the board cells. Each cell also contains a CellState script which handles display of the 'X' and 'O' glyph. 
		
	private Quaternion defaultRotation = Quaternion.identity;			// default rotation for each cell.
		
	private Vector3 cellPosition;
	
	// Generate the game board...
	void Start () {

		gc = GetComponent<GameController>();
		
		theBoard = new GameObject[boardSize, boardSize];	// need somewhere to hold our grid.
		
		// Sanitise inputs. If width and height are zero, adjust them to our default minimums:
		if (cellPrefabWidth < minWidth)	
		{
			cellPrefabWidth = minWidth;
		}
		if (cellPrefabHeight < minHeight)
		{
			cellPrefabHeight = minHeight;
		}
		
		// Calculate centre point of board as camera will be pointed at this. We therefore need to instantiate the prefabs around the origin.
		
		float xOffset = (( (boardSize-0.5f)*cellPrefabWidth)/2); 
		float yOffset = (( (boardSize-2)*cellPrefabHeight)/2); 
		
		// Build our game board.
		for (int row = 0; row < boardSize; row++)
		{
			for (int col = 0; col < boardSize; col++)
			{
				cellPosition = new Vector3((col*cellPrefabWidth)-xOffset, (row*cellPrefabHeight)-yOffset, 0.0f);	// boardSize is used to move the board back to ensure it all fits in the view.
				
				theBoard[row,col] = (GameObject)Instantiate (cellPrefab, cellPosition, defaultRotation);

				// make each new GameObject a child of the root ("GameBoard") transform...
				theBoard[row,col].transform.parent=transform;	// this script should be attached to a suitable 'root' Transform.
			}
		}
		
		boardState = boardStates.init;	// initialisation completed. Camera can now be positioned accordingly.
		
	}
	
	// Returns the board as an array of cellStates.
	public void GetBoard( ref cellStates[,] c)
	{		
		for (int ix=0; ix<boardSize; ++ix)
		{
			for (int iy=0; iy<boardSize; ++iy)
			{
				c[ix,iy] = theBoard[ix,iy].GetComponent<BoardCellState>().cellState;
			}
		}
		
	}
	
	public void ResetBoard ()
	{
		// used to reset the board. This is requested by our View code (which also handles the GUI), which in turn passes it to the Controller, which passes it down to the Model.
		// Which would be this script here.
	
		// Let's do as we've been asked:
		
		foreach (GameObject go in theBoard)
		{
			// The following line illustrates the use of C#'s recently added "generics" feature. The "generic" part is the "<BoardCellState>" bit, which avoids the need to use...
			// ... the older Unity trick of finding a component by searching for it with a text string. The older method was rather slow. This new functionality is much quicker.
			
			go.GetComponent<BoardCellState>().cellState=cellStates.isEmpty;	// Long-winded, isn't it?
		}
		
		boardState = boardStates.playing;		// this is as close as the board get to the "idle" gameState. The Model has no knowledge of the game's UI, so it doesn't need to deal with it.
	
	}
	
	
	public void PlayMoveAt (int ix, int iy, bool isX)
	{
		
		// Set the board cell's cellState accordingly...
		
		cellStates cs;
		
		if (isX == true)
			cs = cellStates.isX;
		else
			cs = cellStates.isO;
		
		theBoard[ix, iy].GetComponent<BoardCellState>().cellState = cs;
		
	}

	// Check for a victory condition. What follows is not particularly optimised, but it is easy to follow bottleneck.
	// In the first release of the demo, this code was in the Update() function above, but I've moved it into its own function instead.
	// Update() runs every game cycle, but we only need to do this test after the player has clicked on the board.
	// The logic is a little bit more complex now: under MVC rules, the GameUI code cannot call this function directly, so it informs GameController instead.
	// GameController then calls the function here in GameBoard on GameUI's behalf. 
	
	public void CheckForVictoryCondition () {
	
		// Cycle through each of our board's cells. If we find a complete row of O or X symbols in either vertical, horizontal or diagonal directions, it's Game Over, dude! Game over!

		// first, check the coloumns...
		
		GameObject currentCell;
		int row, col, rowXCount = 0 , rowOCount = 0, colXCount = 0, colOCount = 0;
		BoardCellState stateScript;
			
		for (row = 0; row < boardSize; row++)
		{
			colOCount = 0; colXCount=0;
			for (col = 0; col < boardSize; col++)
			{
				currentCell = theBoard[row, col];
				stateScript = currentCell.GetComponent<BoardCellState>();	// fetch the Prefab's BoardCellState script.
				if (stateScript.cellState == cellStates.isEmpty)	// is it empty? If so, we're done with this row and column.
					break;
				if (stateScript.cellState == cellStates.isO)
				{
					++colOCount;
				}
				else
				{
					// must be an 'X'
					++colXCount;
				}

			}

			if (colXCount==boardSize)	// we have a winner!
			{
				boardState = boardStates.winnerIsX;
				break;
			}
			if (colOCount==boardSize)	// ditto.
			{
				boardState = boardStates.winnerIsO;
				break;
			}
				
		}
		
		if (boardState == boardStates.playing)	// nothing so far, check the rows...
		{
			for (col = 0; col < boardSize; col++)
			{
				rowOCount = 0; rowXCount=0;
				for (row = 0, rowXCount=0, rowOCount=0; row < boardSize; row++)
				{
					currentCell = theBoard[row, col];
					stateScript = currentCell.GetComponent<BoardCellState>();	// fetch the Prefab's BoardCellState script.
					if (stateScript.cellState == cellStates.isEmpty)	// is it empty? If so, we're done with this row and column.
						break;
					if (stateScript.cellState == cellStates.isO)
					{
						++rowOCount;
					}
					else
					{
						// must be an 'X'
						++rowXCount;
					}
				}
				
				if (rowXCount==boardSize)	// we have a winner!
				{
					boardState = boardStates.winnerIsX;
					break;
				}
				if (rowOCount==boardSize)	// ditto.
				{
					boardState = boardStates.winnerIsO;
					break;
				}
			}
		}
		
		if (boardState == boardStates.playing)	// still nothing? Check diagonals...
		{
			int diagX1 = 0, diagX2 = 0, diagO1 = 0, diagO2 = 0;	// we'll check both at the same time.
			
			for (int a = 0; a < boardSize; a++)
			{
				// first diagonal...
				currentCell = theBoard[a, a];
				stateScript = currentCell.GetComponent<BoardCellState>();	// fetch the Prefab's BoardCellState script.
				if (stateScript.cellState == cellStates.isO)	
					++diagO1;
				if (stateScript.cellState == cellStates.isX)
					++diagX1;
				// must be "isEmpty"
				
				// now check second diagonal...
				currentCell = theBoard[a, (boardSize-1)-a];
				stateScript = currentCell.GetComponent<BoardCellState>();	// fetch the Prefab's BoardCellState script.
				if (stateScript.cellState == cellStates.isO)	
					++diagO2;
				if (stateScript.cellState == cellStates.isX)
					++diagX2;
				// must be "isEmpty"				
			}
			
			if (diagO1 == boardSize || diagO2 == boardSize)
				boardState = boardStates.winnerIsO;
				
			if (diagX1 == boardSize || diagX2 == boardSize)
				boardState = boardStates.winnerIsX;
		}
		
		// finally, if no victory condition has been found, check for stalemate...
		
		if (boardState == boardStates.playing)
		{
			int empties = 0;
			
			foreach (GameObject cell in theBoard)
			{
				if (cell.GetComponent<BoardCellState>().cellState == cellStates.isEmpty)
				{
					++empties;
				}
			}
			
			if (empties == 0)
			{
				// no more free spaces. Stalemate!
				boardState = boardStates.stalemate;
			}
		}
		
		// if boardState is still "playing" at this point, the game is still on.
	}
}
