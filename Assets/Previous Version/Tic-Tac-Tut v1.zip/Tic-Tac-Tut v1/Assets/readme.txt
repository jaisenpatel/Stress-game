## READ ME for TIC-TAC-TUT: Unity Turn-Based Game Tutorial.

This project is completely self-contained. You can either import the downloaded package into an empty Unity project, or you can download the package directly into the project.

The full documentation can be found in the "Tic-Tac-Tut Documentation" PDF included in this folder.


## RELEASE HISTORY

v1.0: This is the initial release. Future releases will list any changes and bug fixes here.
